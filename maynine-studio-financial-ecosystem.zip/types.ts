
export type FabricType = 'Body Fabric' | 'Lining' | 'Accessories';

export interface FabricItem {
  id: string;
  type: FabricType;
  code: string;
  fabrication: string;
  refPrice: number;
}

export interface ComponentConfig {
  fabricItemId: string; // references FabricItem code or id
  colorMode: 'Matched' | 'Fixed';
  fixedColor?: string;
  consumptionPerSize: Record<string, number>;
}

export interface Project {
  id: string;
  config: {
    dressCode: string;
    category: string;
    dressName: string;
    fabrication: string;
    sizes: string[];
    colors: string[];
  };
  fabricDb: FabricItem[];
  orderMatrix: Record<string, Record<string, number>>; // color -> size -> qty
  componentConfigs: ComponentConfig[];
  financialSettings: {
    fixedCost: number;
    sewingCost: number;
    marketingPct: number;
    riskPct: number;
    profitTarget: number;
    retailPrices: Record<string, number>;
    wsPrices: Record<string, number>;
  };
}

export interface AppState {
  projects: Project[];
  selectedProjectId: string | 'dashboard';
  dashboardInclusions: string[]; // List of project IDs
}
