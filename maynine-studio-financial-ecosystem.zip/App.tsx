
import React, { useState, useMemo, useCallback } from 'react';
import { 
  Plus, 
  LayoutDashboard, 
  Settings, 
  Calculator, 
  TrendingUp, 
  DollarSign, 
  ChevronRight, 
  Trash2, 
  Download, 
  CheckCircle2,
  Package,
  Layers,
  BarChart3,
  Lock,
  User,
  LogOut
} from 'lucide-react';
import { Project, AppState, FabricItem, ComponentConfig } from './types';
import { calculateProjectMetrics, formatMMK } from './utils';
import SystemConfig from './components/SystemConfig';
import FabricCalc from './components/FabricCalc';
import ProductionCost from './components/ProductionCost';
import FinancialAnalysis from './components/FinancialAnalysis';
import Dashboard from './components/Dashboard';

const INITIAL_PROJECT_ID = 'DR-001';

const createNewProject = (id: string, code: string): Project => ({
  id,
  config: {
    dressCode: code,
    category: 'Casual',
    dressName: 'New Collection Item',
    fabrication: 'Cotton',
    sizes: ['S', 'M', 'L'],
    colors: ['Red', 'Blue']
  },
  fabricDb: [
    { id: '1', type: 'Body Fabric', code: 'BF-001', fabrication: 'Cotton Twill', refPrice: 4500 },
    { id: '2', type: 'Lining', code: 'LN-001', fabrication: 'Polyester', refPrice: 1200 },
    { id: '3', type: 'Accessories', code: 'AC-001', fabrication: 'Button/Zip Set', refPrice: 800 }
  ],
  orderMatrix: {
    'Red': { 'S': 10, 'M': 15, 'L': 10 },
    'Blue': { 'S': 5, 'M': 10, 'L': 5 }
  },
  componentConfigs: [
    { 
      fabricItemId: 'BF-001', 
      colorMode: 'Matched', 
      consumptionPerSize: { 'S': 1.8, 'M': 2.0, 'L': 2.2 } 
    },
    { 
      fabricItemId: 'LN-001', 
      colorMode: 'Fixed', 
      fixedColor: 'White',
      consumptionPerSize: { 'S': 1.0, 'M': 1.1, 'L': 1.2 } 
    }
  ],
  financialSettings: {
    fixedCost: 500000,
    sewingCost: 3500,
    marketingPct: 5,
    riskPct: 2,
    profitTarget: 40,
    retailPrices: { 'S': 18500, 'M': 18500, 'L': 19500 },
    wsPrices: { 'S': 14000, 'M': 14000, 'L': 15000 }
  }
});

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const [state, setState] = useState<AppState>(() => {
    const initialProject = createNewProject(INITIAL_PROJECT_ID, 'DR-001 Summer Maxi');
    return {
      projects: [initialProject],
      selectedProjectId: 'dashboard',
      dashboardInclusions: [INITIAL_PROJECT_ID]
    };
  });

  const [activeTab, setActiveTab] = useState(0);

  const selectedProject = useMemo(() => 
    state.projects.find(p => p.id === state.selectedProjectId),
    [state.projects, state.selectedProjectId]
  );

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === '@dmin123') {
      setIsLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Invalid username or password');
    }
  };

  const handleAddProject = () => {
    const newId = `DR-${Date.now()}`;
    const codeNum = state.projects.length + 1;
    const newProject = createNewProject(newId, `DR-${String(codeNum).padStart(3, '0')} New Design`);
    setState(prev => ({
      ...prev,
      projects: [...prev.projects, newProject],
      selectedProjectId: newId,
      dashboardInclusions: [...prev.dashboardInclusions, newId]
    }));
  };

  const handleDeleteProject = useCallback((id: string) => {
    if (window.confirm('Are you sure you want to delete this dress code? This action cannot be undone.')) {
      setState(prev => {
        const isSelected = prev.selectedProjectId === id;
        return {
          ...prev,
          projects: prev.projects.filter(p => p.id !== id),
          selectedProjectId: isSelected ? 'dashboard' : prev.selectedProjectId,
          dashboardInclusions: prev.dashboardInclusions.filter(item => item !== id)
        };
      });
    }
  }, []);

  const updateProject = (updated: Project) => {
    setState(prev => ({
      ...prev,
      projects: prev.projects.map(p => p.id === updated.id ? updated : p)
    }));
  };

  const toggleDashboardInclusion = (id: string) => {
    setState(prev => ({
      ...prev,
      dashboardInclusions: prev.dashboardInclusions.includes(id) 
        ? prev.dashboardInclusions.filter(item => item !== id)
        : [...prev.dashboardInclusions, id]
    }));
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-100 p-10 space-y-8">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-50 rounded-2xl text-indigo-600 mb-2">
              <Layers size={32} />
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">MAYNINE STUDIO</h1>
            <p className="text-slate-500 font-medium">Financial Ecosystem Login</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1">Username</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    placeholder="Enter username"
                    required
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    placeholder="Enter password"
                    required
                  />
                </div>
              </div>
            </div>

            {loginError && (
              <p className="text-rose-500 text-xs font-bold text-center bg-rose-50 py-2 rounded-lg">{loginError}</p>
            )}

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 active:scale-[0.98] transition-all"
            >
              Sign In to System
            </button>
          </form>

          <p className="text-center text-[10px] text-slate-400 font-medium">
            Authorized Personnel Only • Maynine Studio Internal Management
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <aside className="w-72 bg-white border-r border-slate-200 flex flex-col shadow-sm z-10">
        <div className="p-6 border-b border-slate-100">
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="text-indigo-600" size={24} />
            MAYNINE <span className="text-slate-400 font-light">STUDIO</span>
          </h1>
          <p className="text-[10px] uppercase tracking-widest text-slate-400 mt-1 font-semibold">Selection Manager</p>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          <button
            onClick={() => setState(prev => ({ ...prev, selectedProjectId: 'dashboard' }))}
            className={`w-full flex items-center justify-between p-3 rounded-xl text-sm font-medium transition-all ${
              state.selectedProjectId === 'dashboard' 
              ? 'bg-indigo-50 text-indigo-700 shadow-sm ring-1 ring-indigo-200' 
              : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <LayoutDashboard size={18} />
              Global Dashboard
            </div>
            <ChevronRight size={14} className={state.selectedProjectId === 'dashboard' ? 'opacity-100' : 'opacity-0'} />
          </button>

          <div className="mt-8 mb-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            Dress Codes
          </div>

          <div className="space-y-1">
            {state.projects.map(project => (
              <div 
                key={project.id}
                className={`group flex items-center p-1 rounded-xl transition-all cursor-pointer ${
                  state.selectedProjectId === project.id ? 'bg-indigo-50 shadow-sm' : 'hover:bg-slate-50'
                }`}
                onClick={() => {
                  setState(prev => ({ ...prev, selectedProjectId: project.id }));
                  setActiveTab(0);
                }}
              >
                <div className="flex items-center pl-2" onClick={(e) => e.stopPropagation()}>
                  <input
                    type="checkbox"
                    checked={state.dashboardInclusions.includes(project.id)}
                    onChange={(e) => {
                      e.stopPropagation();
                      toggleDashboardInclusion(project.id);
                    }}
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>
                <div
                  className={`flex-1 text-left p-2 text-sm font-medium truncate ${
                    state.selectedProjectId === project.id ? 'text-indigo-700' : 'text-slate-600'
                  }`}
                >
                  {project.config.dressCode}
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteProject(project.id);
                  }}
                  className="p-2 text-slate-300 hover:text-rose-500 transition-all opacity-40 group-hover:opacity-100"
                  title="Delete Dress Code"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={handleAddProject}
            className="w-full mt-4 flex items-center justify-center gap-2 p-3 rounded-xl text-sm font-semibold text-indigo-600 border-2 border-dashed border-indigo-100 hover:bg-indigo-50 hover:border-indigo-200 transition-all"
          >
            <Plus size={18} />
            Add Dress Code
          </button>
        </nav>

        <div className="p-4 border-t border-slate-100 bg-slate-50/50 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 px-2">
              <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs">
                AD
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900">Admin User</p>
                <p className="text-[10px] text-slate-500">Premium Account</p>
              </div>
            </div>
            <button 
              onClick={() => setIsLoggedIn(false)}
              className="p-2 text-slate-400 hover:text-rose-500 transition-colors"
              title="Logout"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto bg-slate-50 relative">
        {state.selectedProjectId === 'dashboard' ? (
          <Dashboard 
            projects={state.projects.filter(p => state.dashboardInclusions.includes(p.id))} 
          />
        ) : selectedProject ? (
          <div className="max-w-7xl mx-auto p-8 space-y-6 pb-20">
            <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <nav className="flex items-center gap-2 text-xs text-slate-400 mb-2 font-medium">
                  <span>Selection Manager</span>
                  <ChevronRight size={10} />
                  <span className="text-slate-600">{selectedProject.config.dressCode}</span>
                </nav>
                <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {selectedProject.config.dressName}
                </h2>
                <p className="text-slate-500 font-medium">Project Lifecycle Management & Financial Analysis</p>
              </div>

              <div className="flex bg-white p-1 rounded-xl shadow-sm border border-slate-200 self-start">
                {['System Config', '1. Fabric Calc', '2. Production Cost', '3. Financial Analysis'].map((tab, idx) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(idx)}
                    className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                      activeTab === idx 
                      ? 'bg-indigo-600 text-white shadow-md' 
                      : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </header>

            <div className="transition-all duration-300">
              {activeTab === 0 && <SystemConfig project={selectedProject} updateProject={updateProject} deleteProject={handleDeleteProject} />}
              {activeTab === 1 && <FabricCalc project={selectedProject} updateProject={updateProject} />}
              {activeTab === 2 && <ProductionCost project={selectedProject} updateProject={updateProject} />}
              {activeTab === 3 && <FinancialAnalysis project={selectedProject} updateProject={updateProject} />}
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-400 flex-col gap-4">
            <Layers size={48} className="opacity-20" />
            <p>Select a project or dashboard from the sidebar</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
