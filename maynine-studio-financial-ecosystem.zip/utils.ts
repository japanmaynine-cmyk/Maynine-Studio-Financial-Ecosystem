
import { Project, FabricItem } from './types';

export const formatMMK = (val: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'decimal',
    maximumFractionDigits: 0,
  }).format(val) + ' MMK';
};

export const calculateProjectMetrics = (project: Project) => {
  const { orderMatrix, componentConfigs, fabricDb, financialSettings, config } = project;
  
  let totalUnits = 0;
  Object.values(orderMatrix).forEach(sizes => {
    Object.values(sizes).forEach(qty => {
      totalUnits += (qty || 0);
    });
  });

  const fabricRequirements: Record<string, { code: string, color: string, yards: number }> = {};
  
  componentConfigs.forEach(comp => {
    const fabricItem = fabricDb.find(f => f.code === comp.fabricItemId);
    if (!fabricItem) return;

    Object.entries(orderMatrix).forEach(([color, sizes]) => {
      Object.entries(sizes).forEach(([size, qty]) => {
        const consRate = comp.consumptionPerSize[size] || 0;
        const totalReq = consRate * (qty || 0);
        const targetColor = comp.colorMode === 'Matched' ? color : (comp.fixedColor || 'Default');
        const key = `${comp.fabricItemId}-${targetColor}`;
        
        if (!fabricRequirements[key]) {
          fabricRequirements[key] = { code: comp.fabricItemId, color: targetColor, yards: 0 };
        }
        fabricRequirements[key].yards += totalReq;
      });
    });
  });

  // Financials
  let totalVariableBaseCost = 0;
  const unitVariableCosts: Record<string, number> = {}; // per size

  config.sizes.forEach(size => {
    let sizeBaseCost = 0;
    componentConfigs.forEach(comp => {
      const fabricItem = fabricDb.find(f => f.code === comp.fabricItemId);
      if (!fabricItem) return;
      const consRate = comp.consumptionPerSize[size] || 0;
      sizeBaseCost += consRate * fabricItem.refPrice;
    });
    sizeBaseCost += (financialSettings.sewingCost || 0);
    
    // Add markups (marketing, risk)
    const marketingCost = sizeBaseCost * (financialSettings.marketingPct / 100);
    const riskCost = sizeBaseCost * (financialSettings.riskPct / 100);
    const finalSizeUnitCost = sizeBaseCost + marketingCost + riskCost;
    
    unitVariableCosts[size] = finalSizeUnitCost;

    // Aggregate total variable cost based on production qty
    Object.values(orderMatrix).forEach(sizes => {
      totalVariableBaseCost += (sizes[size] || 0) * finalSizeUnitCost;
    });
  });

  const totalInvestment = totalVariableBaseCost + (financialSettings.fixedCost || 0);

  let totalRevenue = 0;
  config.sizes.forEach(size => {
    const price = financialSettings.retailPrices[size] || 0;
    Object.values(orderMatrix).forEach(sizes => {
      totalRevenue += (sizes[size] || 0) * price;
    });
  });

  const grossProfit = totalRevenue - totalInvestment;

  // Average logic for BEP
  const avgSalesPrice = totalUnits > 0 ? totalRevenue / totalUnits : 0;
  const avgVarCost = totalUnits > 0 ? totalVariableBaseCost / totalUnits : 0;
  const contributionMargin = avgSalesPrice - avgVarCost;
  const bepUnits = contributionMargin > 0 ? (financialSettings.fixedCost || 0) / contributionMargin : 0;

  return {
    totalUnits,
    totalInvestment,
    totalRevenue,
    grossProfit,
    bepUnits,
    fabricRequirements: Object.values(fabricRequirements),
    unitVariableCosts,
    totalVariableBaseCost,
    avgSalesPrice,
    avgVarCost
  };
};
