
import React, { useMemo } from 'react';
import { DollarSign, ShieldAlert, Percent, Settings } from 'lucide-react';
import { Project } from '../types';
import { calculateProjectMetrics, formatMMK } from '../utils';

interface Props {
  project: Project;
  updateProject: (p: Project) => void;
}

const ProductionCost: React.FC<Props> = ({ project, updateProject }) => {
  const { financialSettings, fabricDb, config } = project;
  const metrics = useMemo(() => calculateProjectMetrics(project), [project]);

  const updateFin = (field: string, value: any) => {
    updateProject({
      ...project,
      financialSettings: { ...financialSettings, [field]: value }
    });
  };

  const updatePrice = (type: 'retail' | 'ws', size: string, value: number) => {
    const field = type === 'retail' ? 'retailPrices' : 'wsPrices';
    updateProject({
      ...project,
      financialSettings: {
        ...financialSettings,
        [field]: { ...financialSettings[field], [size]: value }
      }
    });
  };

  const accessoryCost = useMemo(() => {
    const item = fabricDb.find(f => f.type === 'Accessories');
    return item ? item.refPrice : 0;
  }, [fabricDb]);

  return (
    <div className="space-y-8">
      {/* Global Cost Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
            <DollarSign size={10} /> Fixed Cost (Salary)
          </label>
          <input
            type="number"
            value={financialSettings.fixedCost}
            onChange={(e) => updateFin('fixedCost', parseFloat(e.target.value) || 0)}
            className="text-xl font-extrabold text-slate-800 outline-none border-b-2 border-slate-50 focus:border-indigo-500 bg-transparent transition-colors"
          />
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
            <Settings size={10} /> Sewing Cost/Unit
          </label>
          <input
            type="number"
            value={financialSettings.sewingCost}
            onChange={(e) => updateFin('sewingCost', parseFloat(e.target.value) || 0)}
            className="text-xl font-extrabold text-slate-800 outline-none border-b-2 border-slate-50 focus:border-indigo-500 bg-transparent transition-colors"
          />
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
            <Percent size={10} /> Marketing %
          </label>
          <input
            type="number"
            value={financialSettings.marketingPct}
            onChange={(e) => updateFin('marketingPct', parseFloat(e.target.value) || 0)}
            className="text-xl font-extrabold text-slate-800 outline-none border-b-2 border-slate-50 focus:border-indigo-500 bg-transparent transition-colors"
          />
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
            <ShieldAlert size={10} /> Risk %
          </label>
          <input
            type="number"
            value={financialSettings.riskPct}
            onChange={(e) => updateFin('riskPct', parseFloat(e.target.value) || 0)}
            className="text-xl font-extrabold text-slate-800 outline-none border-b-2 border-slate-50 focus:border-indigo-500 bg-transparent transition-colors"
          />
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Accessory/Unit</label>
          <div className="text-xl font-extrabold text-slate-400">{formatMMK(accessoryCost)}</div>
          <p className="text-[8px] text-slate-400">Linked from Fabric Database</p>
        </div>
      </div>

      {/* Investment Breakdown Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-50">
          <h3 className="text-lg font-bold text-slate-900">Unit Investment Breakdown (Per Size)</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                <th className="px-6 py-4">Size</th>
                <th className="px-6 py-4">Base Cost (Fabrics)</th>
                <th className="px-6 py-4">Sewing</th>
                <th className="px-6 py-4">Accessories</th>
                <th className="px-6 py-4 text-rose-500">Marketing & Risk</th>
                <th className="px-6 py-4 text-indigo-600">Total Unit Invest</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {config.sizes.map(size => {
                let fabricCost = 0;
                project.componentConfigs.forEach(comp => {
                  const item = fabricDb.find(f => f.code === comp.fabricItemId);
                  if (item) fabricCost += (comp.consumptionPerSize[size] || 0) * item.refPrice;
                });
                const unitInvest = metrics.unitVariableCosts[size] || 0;
                const markups = unitInvest - fabricCost - financialSettings.sewingCost - accessoryCost;

                return (
                  <tr key={size} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-3 font-bold text-slate-800">{size}</td>
                    <td className="px-6 py-3 text-sm text-slate-600">{formatMMK(fabricCost)}</td>
                    <td className="px-6 py-3 text-sm text-slate-600">{formatMMK(financialSettings.sewingCost)}</td>
                    <td className="px-6 py-3 text-sm text-slate-600">{formatMMK(accessoryCost)}</td>
                    <td className="px-6 py-3 text-sm text-rose-500">{formatMMK(markups)}</td>
                    <td className="px-6 py-3 text-sm font-bold text-indigo-600">{formatMMK(unitInvest)}</td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-50 font-bold text-slate-700">
              <tr>
                <td colSpan={5} className="px-6 py-4 text-right text-[10px] uppercase tracking-widest text-slate-400">Total Variable Investment</td>
                <td className="px-6 py-4">{formatMMK(metrics.totalVariableBaseCost)}</td>
              </tr>
              <tr>
                <td colSpan={5} className="px-6 py-4 text-right text-[10px] uppercase tracking-widest text-slate-400">Fixed Cost (Allocated)</td>
                <td className="px-6 py-4 border-b border-slate-200">{formatMMK(financialSettings.fixedCost)}</td>
              </tr>
              <tr className="bg-indigo-600 text-white">
                <td colSpan={5} className="px-6 py-4 text-right uppercase tracking-widest">Total Project Investment</td>
                <td className="px-6 py-4 text-lg">{formatMMK(metrics.totalInvestment)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Sales & Profitability */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900">Sales & Profitability Analysis</h3>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Global Target</span>
            <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-2 py-1">
              <input
                type="number"
                value={financialSettings.profitTarget}
                onChange={(e) => updateFin('profitTarget', parseFloat(e.target.value) || 0)}
                className="w-10 bg-transparent text-sm font-bold outline-none text-indigo-600"
              />
              <span className="text-xs font-bold text-indigo-600">%</span>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                <th className="px-6 py-4">Size</th>
                <th className="px-6 py-4">Var Cost</th>
                <th className="px-6 py-4">Profit Amt</th>
                <th className="px-6 py-4">Calc Price</th>
                <th className="px-6 py-4 text-indigo-600">Retail Price</th>
                <th className="px-6 py-4 text-emerald-600">WS Price</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {config.sizes.map(size => {
                const varCost = metrics.unitVariableCosts[size] || 0;
                const profitAmt = varCost * (financialSettings.profitTarget / 100);
                const calcPrice = varCost + profitAmt;
                
                return (
                  <tr key={size} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-3 font-bold text-slate-800">{size}</td>
                    <td className="px-6 py-3 text-sm text-slate-600">{formatMMK(varCost)}</td>
                    <td className="px-6 py-3 text-sm text-slate-400">{formatMMK(profitAmt)}</td>
                    <td className="px-6 py-3 text-sm text-slate-400 italic">{formatMMK(calcPrice)}</td>
                    <td className="px-6 py-3">
                      <input
                        type="number"
                        value={financialSettings.retailPrices[size]}
                        onChange={(e) => updatePrice('retail', size, parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-sm font-bold text-indigo-600 outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="px-6 py-3">
                      <input
                        type="number"
                        value={financialSettings.wsPrices[size]}
                        onChange={(e) => updatePrice('ws', size, parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-sm font-bold text-emerald-600 outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductionCost;
