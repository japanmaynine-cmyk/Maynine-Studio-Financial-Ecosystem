
import React, { useState } from 'react';
import { Plus, X, Tag, Database, List, Trash2, AlertTriangle } from 'lucide-react';
import { Project, FabricItem, FabricType } from '../types';

interface Props {
  project: Project;
  updateProject: (p: Project) => void;
  deleteProject: (id: string) => void;
}

const SystemConfig: React.FC<Props> = ({ project, updateProject, deleteProject }) => {
  const [newSize, setNewSize] = useState('');
  const [newColor, setNewColor] = useState('');

  const updateConfig = (field: string, value: any) => {
    updateProject({
      ...project,
      config: { ...project.config, [field]: value }
    });
  };

  const addTag = (type: 'sizes' | 'colors', value: string) => {
    if (!value || project.config[type].includes(value)) return;
    updateConfig(type, [...project.config[type], value]);
    if (type === 'sizes') setNewSize('');
    else setNewColor('');
  };

  const removeTag = (type: 'sizes' | 'colors', value: string) => {
    updateConfig(type, project.config[type].filter(t => t !== value));
  };

  const addFabricItem = () => {
    const newItem: FabricItem = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'Body Fabric',
      code: `FB-${Math.floor(Math.random() * 999)}`,
      fabrication: 'New Material',
      refPrice: 0
    };
    updateProject({
      ...project,
      fabricDb: [...project.fabricDb, newItem]
    });
  };

  const updateFabricItem = (id: string, field: keyof FabricItem, value: any) => {
    const updatedDb = project.fabricDb.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    );
    updateProject({ ...project, fabricDb: updatedDb });
  };

  const deleteFabricItem = (id: string) => {
    updateProject({
      ...project,
      fabricDb: project.fabricDb.filter(i => i.id !== id)
    });
  };

  return (
    <div className="space-y-8">
      {/* Basic Meta Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ConfigField label="Dress Code" value={project.config.dressCode} onChange={(v) => updateConfig('dressCode', v)} />
        <ConfigField label="Category" value={project.config.category} onChange={(v) => updateConfig('category', v)} />
        <ConfigField label="Dress Name" value={project.config.dressName} onChange={(v) => updateConfig('dressName', v)} />
        <ConfigField label="Fabrication" value={project.config.fabrication} onChange={(v) => updateConfig('fabrication', v)} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Size Manager */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Tag size={16} className="text-indigo-500" />
              Size Management
            </h3>
          </div>
          <div className="flex flex-wrap gap-2 mb-4">
            {project.config.sizes.map(size => (
              <span key={size} className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border border-slate-200">
                {size}
                <button onClick={() => removeTag('sizes', size)} className="hover:text-rose-500 transition-colors">
                  <X size={14} />
                </button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add Size (e.g. XL)"
              value={newSize}
              onChange={(e) => setNewSize(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addTag('sizes', newSize)}
              className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button onClick={() => addTag('sizes', newSize)} className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700">
              <Plus size={20} />
            </button>
          </div>
        </div>

        {/* Color Manager */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Tag size={16} className="text-emerald-500" />
              Color Management
            </h3>
          </div>
          <div className="flex flex-wrap gap-2 mb-4">
            {project.config.colors.map(color => (
              <span key={color} className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border border-slate-200">
                <div className="w-3 h-3 rounded-full border border-slate-300" style={{backgroundColor: color.toLowerCase()}} />
                {color}
                <button onClick={() => removeTag('colors', color)} className="hover:text-rose-500 transition-colors">
                  <X size={14} />
                </button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add Color (e.g. Sage)"
              value={newColor}
              onChange={(e) => setNewColor(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addTag('colors', newColor)}
              className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button onClick={() => addTag('colors', newColor)} className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700">
              <Plus size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Fabric Database */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Database size={20} className="text-indigo-600" />
            Fabric Database
          </h3>
          <button
            onClick={addFabricItem}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-all"
          >
            <Plus size={16} /> Add Component
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Code</th>
                <th className="px-6 py-4">Fabrication</th>
                <th className="px-6 py-4">Price (MMK/Yd)</th>
                <th className="px-6 py-4 w-20"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {project.fabricDb.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-3">
                    <select
                      value={item.type}
                      onChange={(e) => updateFabricItem(item.id, 'type', e.target.value)}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs focus:ring-1 focus:ring-indigo-500 outline-none"
                    >
                      <option value="Body Fabric">Body Fabric</option>
                      <option value="Lining">Lining</option>
                      <option value="Accessories">Accessories</option>
                    </select>
                  </td>
                  <td className="px-6 py-3">
                    <input
                      type="text"
                      value={item.code}
                      onChange={(e) => updateFabricItem(item.id, 'code', e.target.value)}
                      className="bg-transparent text-xs font-bold outline-none border-b border-transparent focus:border-indigo-300 transition-colors"
                    />
                  </td>
                  <td className="px-6 py-3">
                    <input
                      type="text"
                      value={item.fabrication}
                      onChange={(e) => updateFabricItem(item.id, 'fabrication', e.target.value)}
                      className="bg-transparent text-xs outline-none border-b border-transparent focus:border-indigo-300 transition-colors w-full"
                    />
                  </td>
                  <td className="px-6 py-3">
                    <input
                      type="number"
                      value={item.refPrice}
                      onChange={(e) => updateFabricItem(item.id, 'refPrice', parseFloat(e.target.value) || 0)}
                      className="bg-transparent text-xs font-mono outline-none border-b border-transparent focus:border-indigo-300 transition-colors"
                    />
                  </td>
                  <td className="px-6 py-3 text-right">
                    <button
                      onClick={() => deleteFabricItem(item.id)}
                      className="text-slate-300 hover:text-rose-500 transition-all opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Section */}
      <div className="bg-rose-50 border border-rose-100 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-rose-100 rounded-2xl text-rose-600">
            <AlertTriangle size={24} />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">Danger Zone</h4>
            <p className="text-xs text-slate-500">Deleting this dress code will permanently remove all associated fabric logic and financial data.</p>
          </div>
        </div>
        <button
          onClick={() => deleteProject(project.id)}
          className="flex items-center gap-2 px-6 py-3 bg-rose-600 text-white rounded-2xl text-sm font-bold shadow-lg shadow-rose-100 hover:bg-rose-700 transition-all active:scale-95"
        >
          <Trash2 size={18} />
          Delete Dress Code
        </button>
      </div>
    </div>
  );
};

const ConfigField = ({ label, value, onChange }: { label: string, value: string, onChange: (v: string) => void }) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-2">
    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{label}</label>
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full text-sm font-bold text-slate-800 bg-transparent border-b-2 border-slate-50 focus:border-indigo-500 outline-none pb-1 transition-colors"
    />
  </div>
);

export default SystemConfig;
