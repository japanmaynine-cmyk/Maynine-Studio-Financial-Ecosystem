
import React from 'react';
import { Ruler, Settings2, Download, Table as TableIcon, Trash2, Plus } from 'lucide-react';
import { Project, ComponentConfig } from '../types';
import { calculateProjectMetrics } from '../utils';

interface Props {
  project: Project;
  updateProject: (p: Project) => void;
}

const FabricCalc: React.FC<Props> = ({ project, updateProject }) => {
  const { config, fabricDb, orderMatrix, componentConfigs } = project;

  const updateMatrix = (color: string, size: string, value: number) => {
    const newMatrix = { ...orderMatrix };
    if (!newMatrix[color]) newMatrix[color] = {};
    newMatrix[color][size] = value;
    updateProject({ ...project, orderMatrix: newMatrix });
  };

  const updateComponent = (index: number, field: keyof ComponentConfig, value: any) => {
    const updated = [...componentConfigs];
    updated[index] = { ...updated[index], [field]: value };
    updateProject({ ...project, componentConfigs: updated });
  };

  const updateConsRate = (compIdx: number, size: string, val: number) => {
    const updated = [...componentConfigs];
    updated[compIdx].consumptionPerSize = { 
      ...updated[compIdx].consumptionPerSize, 
      [size]: val 
    };
    updateProject({ ...project, componentConfigs: updated });
  };

  const addComponentConfig = () => {
    const newComp: ComponentConfig = {
      fabricItemId: fabricDb[0]?.code || '',
      colorMode: 'Matched',
      consumptionPerSize: config.sizes.reduce((acc, s) => ({ ...acc, [s]: 0 }), {})
    };
    updateProject({ ...project, componentConfigs: [...componentConfigs, newComp] });
  };

  const removeComponentConfig = (index: number) => {
    const updated = componentConfigs.filter((_, i) => i !== index);
    updateProject({ ...project, componentConfigs: updated });
  };

  const exportCSV = () => {
    const metrics = calculateProjectMetrics(project);
    let csv = "Fabric Type,Code,Color,Required Yards\n";
    metrics.fabricRequirements.forEach(req => {
      const item = fabricDb.find(f => f.code === req.code);
      csv += `${item?.type || 'N/A'},${req.code},${req.color},${req.yards.toFixed(2)}\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.config.dressCode}_fabric_breakdown.csv`;
    a.click();
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Production Matrix */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <TableIcon size={20} className="text-indigo-600" />
            Production Order Matrix
          </h3>
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Qty per Size vs Color</div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                <th className="px-6 py-4">Color</th>
                {config.sizes.map(s => <th key={s} className="px-6 py-4">{s}</th>)}
                <th className="px-6 py-4 text-slate-800">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {config.colors.map(color => {
                let rowTotal = 0;
                return (
                  <tr key={color} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-3 font-bold text-slate-700">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{backgroundColor: color.toLowerCase()}} />
                        {color}
                      </div>
                    </td>
                    {config.sizes.map(size => {
                      const val = orderMatrix[color]?.[size] || 0;
                      rowTotal += val;
                      return (
                        <td key={size} className="px-6 py-3">
                          <input
                            type="number"
                            value={val}
                            onChange={(e) => updateMatrix(color, size, parseInt(e.target.value) || 0)}
                            className="w-20 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-sm text-center outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                          />
                        </td>
                      );
                    })}
                    <td className="px-6 py-3 font-bold text-indigo-600 bg-slate-50/50">{rowTotal}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Component Logic Layers */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Settings2 size={20} className="text-indigo-600" />
            Consumption Logic Layers
          </h3>
          <div className="flex gap-2">
            <button
              onClick={exportCSV}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-50 transition-all"
            >
              <Download size={16} /> Export CSV
            </button>
            <button
              onClick={addComponentConfig}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all"
            >
              <Plus size={16} /> Add Logic Layer
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {componentConfigs.map((comp, idx) => (
            <div key={idx} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px] font-bold">
                    {idx + 1}
                  </span>
                  <select
                    value={comp.fabricItemId}
                    onChange={(e) => updateComponent(idx, 'fabricItemId', e.target.value)}
                    className="bg-white border border-slate-200 rounded-lg px-3 py-1 text-xs font-bold focus:ring-1 focus:ring-indigo-500 outline-none"
                  >
                    {fabricDb.map(f => (
                      <option key={f.code} value={f.code}>{f.type}: {f.code} ({f.fabrication})</option>
                    ))}
                  </select>
                  <select
                    value={comp.colorMode}
                    onChange={(e) => updateComponent(idx, 'colorMode', e.target.value)}
                    className="bg-white border border-slate-200 rounded-lg px-3 py-1 text-xs font-medium focus:ring-1 focus:ring-indigo-500 outline-none"
                  >
                    <option value="Matched">Color Matched</option>
                    <option value="Fixed">Fixed Color</option>
                  </select>
                  {comp.colorMode === 'Fixed' && (
                    <input
                      type="text"
                      placeholder="Fixed Color Name"
                      value={comp.fixedColor}
                      onChange={(e) => updateComponent(idx, 'fixedColor', e.target.value)}
                      className="bg-white border border-slate-200 rounded-lg px-3 py-1 text-xs outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  )}
                </div>
                <button
                  onClick={() => removeComponentConfig(idx)}
                  className="p-2 text-slate-300 hover:text-rose-500 transition-all"
                >
                  <Trash2 size={16} />
                </button>
              </div>
              <div className="p-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
                {config.sizes.map(size => (
                  <div key={size} className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{size} Consumption</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        step="0.01"
                        value={comp.consumptionPerSize[size]}
                        onChange={(e) => updateConsRate(idx, size, parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-bold text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                      />
                      <span className="text-[10px] font-bold text-slate-400">YDS</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FabricCalc;
