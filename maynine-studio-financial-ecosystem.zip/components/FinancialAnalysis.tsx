
import React, { useMemo } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  ReferenceLine,
  Label
} from 'recharts';
import { DollarSign, TrendingUp, Calculator, Package, Target } from 'lucide-react';
import { Project } from '../types';
import { calculateProjectMetrics, formatMMK } from '../utils';

interface Props {
  project: Project;
  updateProject: (p: Project) => void;
}

const FinancialAnalysis: React.FC<Props> = ({ project }) => {
  const metrics = useMemo(() => calculateProjectMetrics(project), [project]);

  const bepData = useMemo(() => {
    const data = [];
    const actualUnits = metrics.totalUnits;
    const bepUnits = Math.ceil(metrics.bepUnits);
    const maxUnits = Math.max(actualUnits * 1.5, bepUnits * 1.5, 20);
    const step = Math.ceil(maxUnits / 10) || 1;

    for (let i = 0; i <= maxUnits; i += step) {
      data.push({
        units: i,
        fixedCost: project.financialSettings.fixedCost,
        totalCost: project.financialSettings.fixedCost + (metrics.avgVarCost * i),
        revenue: metrics.avgSalesPrice * i
      });
    }
    return data;
  }, [project, metrics]);

  return (
    <div className="space-y-8 pb-20">
      {/* Header Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnalysisCard 
          title="Total Investment" 
          value={formatMMK(metrics.totalInvestment)} 
          subtitle="Fixed + Variable Costs"
          icon={<DollarSign className="text-rose-500" />} 
        />
        <AnalysisCard 
          title="Total Revenue" 
          value={formatMMK(metrics.totalRevenue)} 
          subtitle={`At current unit prices`}
          icon={<TrendingUp className="text-emerald-500" />} 
        />
        <AnalysisCard 
          title="Gross Profit" 
          value={formatMMK(metrics.grossProfit)} 
          subtitle={`${((metrics.grossProfit / (metrics.totalInvestment || 1)) * 100).toFixed(1)}% ROI`}
          icon={<Calculator className="text-indigo-500" />} 
          highlight={metrics.grossProfit > 0}
        />
        <AnalysisCard 
          title="Total BEP Units" 
          value={`${Math.ceil(metrics.bepUnits)} Units`} 
          subtitle="Break-Even Point"
          icon={<Target className="text-amber-500" />} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* BEP Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Financial Break-Even Chart</h3>
              <p className="text-xs text-slate-500">Unit sales vs Costs & Revenue</p>
            </div>
            <div className="flex items-center gap-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">
              <div className="flex items-center gap-1"><div className="w-3 h-0.5 bg-slate-300"></div> Fixed</div>
              <div className="flex items-center gap-1"><div className="w-3 h-0.5 bg-rose-400"></div> Total Cost</div>
              <div className="flex items-center gap-1"><div className="w-3 h-0.5 bg-emerald-400"></div> Revenue</div>
            </div>
          </div>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={bepData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="units" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 11}} 
                  label={{ value: 'Units Sold', position: 'bottom', offset: 0, fill: '#94a3b8', fontSize: 10, fontWeight: 'bold' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 11}} 
                  tickFormatter={(val) => `${(val / 1000).toFixed(0)}k`}
                />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
                  formatter={(val: number) => formatMMK(val)}
                />
                <Line type="monotone" dataKey="fixedCost" stroke="#cbd5e1" strokeWidth={2} dot={false} strokeDasharray="5 5" name="Fixed Cost" />
                <Line type="monotone" dataKey="totalCost" stroke="#fb7185" strokeWidth={3} dot={false} name="Total Cost" />
                <Line type="monotone" dataKey="revenue" stroke="#34d399" strokeWidth={3} dot={false} name="Revenue" />
                
                {/* Intersection Reference */}
                <ReferenceLine x={metrics.bepUnits} stroke="#f59e0b" strokeDasharray="3 3">
                   <Label value="BEP" position="top" fill="#f59e0b" fontSize={10} fontWeight="bold" />
                </ReferenceLine>
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Efficiency Stats */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Calculator size={16} className="text-indigo-500" />
              Efficiency Breakdown
            </h3>
            <div className="space-y-4">
              <MetricItem label="Avg Sale Price" value={formatMMK(metrics.avgSalesPrice)} />
              <MetricItem label="Avg Var Cost" value={formatMMK(metrics.avgVarCost)} />
              <MetricItem label="Cont. Margin" value={formatMMK(metrics.avgSalesPrice - metrics.avgVarCost)} color="text-emerald-600" />
              <MetricItem label="Margin Ratio" value={`${(((metrics.avgSalesPrice - metrics.avgVarCost) / (metrics.avgSalesPrice || 1)) * 100).toFixed(1)}%`} />
            </div>
          </div>

          <div className="bg-indigo-600 p-6 rounded-2xl shadow-lg shadow-indigo-100 text-white">
            <h3 className="text-sm font-bold mb-4">Investment Analysis</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-xs opacity-80">
                <span>Variable Capital</span>
                <span>{formatMMK(metrics.totalVariableBaseCost)}</span>
              </div>
              <div className="flex justify-between text-xs opacity-80">
                <span>Fixed Capital</span>
                <span>{formatMMK(project.financialSettings.fixedCost)}</span>
              </div>
              <div className="pt-2 mt-2 border-t border-indigo-400 flex justify-between font-bold">
                <span>Total Budget</span>
                <span>{formatMMK(metrics.totalInvestment)}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-slate-900 p-6 rounded-2xl text-white">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-emerald-500/20 rounded-lg">
                <Package className="text-emerald-400" size={20} />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">Target Achievement</p>
                <p className="text-lg font-bold">
                  {((metrics.totalUnits / (Math.ceil(metrics.bepUnits) || 1)) * 100).toFixed(0)}%
                </p>
              </div>
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
               <div 
                 className="bg-emerald-500 h-full transition-all duration-1000" 
                 style={{width: `${Math.min(100, (metrics.totalUnits / (Math.ceil(metrics.bepUnits) || 1)) * 100)}%`}} 
               />
            </div>
            <p className="text-[10px] mt-2 text-slate-400">Current production: {metrics.totalUnits} / {Math.ceil(metrics.bepUnits)} Units for BEP</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const AnalysisCard = ({ title, value, subtitle, icon, highlight }: { title: string, value: string, subtitle: string, icon: React.ReactNode, highlight?: boolean }) => (
  <div className={`bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-1 transition-all ${highlight ? 'ring-2 ring-emerald-100 shadow-md scale-[1.02]' : ''}`}>
    <div className="flex items-center justify-between text-slate-400 mb-1">
      <span className="text-[10px] font-bold uppercase tracking-widest">{title}</span>
      {icon}
    </div>
    <div className="text-xl font-extrabold text-slate-900">{value}</div>
    <div className="text-[10px] text-slate-500 font-medium">{subtitle}</div>
  </div>
);

const MetricItem = ({ label, value, color = "text-slate-900" }: { label: string, value: string, color?: string }) => (
  <div className="flex items-center justify-between border-b border-slate-50 pb-2">
    <span className="text-xs text-slate-500 font-medium">{label}</span>
    <span className={`text-sm font-bold ${color}`}>{value}</span>
  </div>
);

export default FinancialAnalysis;
