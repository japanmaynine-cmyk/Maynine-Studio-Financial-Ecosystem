
import React, { useState, useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { Package, DollarSign, TrendingUp, Target, Ruler, Layers, ChevronRight } from 'lucide-react';
import { Project } from '../types';
import { calculateProjectMetrics, formatMMK } from '../utils';

interface DashboardProps {
  projects: Project[];
}

// Interface for project performance metrics used in dashboard views
interface ProjectSnapshot {
  name: string;
  investment: number;
  revenue: number;
  profit: number;
  units: number;
  bep: number;
  fabric: number;
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

const Dashboard: React.FC<DashboardProps> = ({ projects }) => {
  const [view, setView] = useState<'fabric' | 'financial'>('financial');

  const aggregated = useMemo(() => {
    let totalInvestment = 0;
    let totalRevenue = 0;
    let totalUnits = 0;
    let totalFabricReq = 0;
    const fabricByType: Record<string, number> = {};
    // Use the ProjectSnapshot interface to ensure type safety in the views
    const projectSnapshots: ProjectSnapshot[] = [];
    const colorBreakdown: Record<string, number> = {};
    
    // Grouped fabric data for "Production Breakdown by Fabric Color"
    // Key: color-code
    const fabricColorMatrix: Record<string, { color: string, code: string, yards: number }> = {};

    projects.forEach(p => {
      const metrics = calculateProjectMetrics(p);
      totalInvestment += metrics.totalInvestment;
      totalRevenue += metrics.totalRevenue;
      totalUnits += metrics.totalUnits;
      
      metrics.fabricRequirements.forEach(req => {
        totalFabricReq += req.yards;
        colorBreakdown[req.color] = (colorBreakdown[req.color] || 0) + req.yards;
        
        const key = `${req.color}-${req.code}`;
        if (!fabricColorMatrix[key]) {
          fabricColorMatrix[key] = { color: req.color, code: req.code, yards: 0 };
        }
        fabricColorMatrix[key].yards += req.yards;
      });

      p.fabricDb.forEach(item => {
        const reqs = metrics.fabricRequirements.filter(r => r.code === item.code);
        const yards = reqs.reduce((sum, r) => sum + r.yards, 0);
        fabricByType[item.type] = (fabricByType[item.type] || 0) + yards;
      });

      projectSnapshots.push({
        name: p.config.dressCode,
        investment: metrics.totalInvestment,
        revenue: metrics.totalRevenue,
        profit: metrics.grossProfit,
        units: metrics.totalUnits,
        bep: metrics.bepUnits,
        fabric: metrics.fabricRequirements.reduce((acc, r) => acc + r.yards, 0)
      });
    });

    return {
      totalInvestment,
      totalRevenue,
      grossProfit: totalRevenue - totalInvestment,
      totalUnits,
      totalFabricReq,
      fabricByType,
      projectSnapshots,
      colorBreakdown,
      fabricColorMatrix: Object.values(fabricColorMatrix),
      avgCons: totalUnits > 0 ? totalFabricReq / totalUnits : 0
    };
  }, [projects]);

  // Fix: Explicitly cast value as number to resolve 'unknown' type inference issues
  const pieData = Object.entries(aggregated.fabricByType).map(([name, value]) => ({ name, value: value as number }));

  return (
    <div className="max-w-7xl mx-auto p-8 space-y-8 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Global Aggregation</h2>
          <p className="text-slate-500 font-medium">Real-time portfolio insights from {projects.length} active designs</p>
        </div>
        <div className="flex bg-white p-1 rounded-xl shadow-sm border border-slate-200 self-start">
          <button
            onClick={() => setView('fabric')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${
              view === 'fabric' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Ruler size={14} />
            Fabric View (Yards)
          </button>
          <button
            onClick={() => setView('financial')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${
              view === 'financial' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <DollarSign size={14} />
            Financial View (MMK)
          </button>
        </div>
      </header>

      {view === 'financial' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Total Investment" value={formatMMK(aggregated.totalInvestment)} icon={<DollarSign className="text-rose-500" />} />
          <StatCard title="Total Revenue" value={formatMMK(aggregated.totalRevenue)} icon={<TrendingUp className="text-emerald-500" />} />
          <StatCard title="Gross Profit" value={formatMMK(aggregated.grossProfit)} icon={<TrendingUp className="text-indigo-500" />} highlight={aggregated.grossProfit > 0} />
          <StatCard title="Total Units" value={`${aggregated.totalUnits} Pcs`} icon={<Package className="text-slate-400" />} />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Total Fabric Req" value={`${aggregated.totalFabricReq.toFixed(1)} Yds`} icon={<Ruler className="text-indigo-500" />} />
          <StatCard title="Total Production" value={`${aggregated.totalUnits} Pcs`} icon={<Package className="text-emerald-500" />} />
          <StatCard title="Avg Cons/Unit" value={`${aggregated.avgCons.toFixed(2)} Yds`} icon={<Layers className="text-slate-400" />} />
          <StatCard title="Fabric Types" value={Object.keys(aggregated.fabricByType).length.toString()} icon={<Target className="text-slate-400" />} />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6">{view === 'financial' ? 'Financial Snapshot by Project' : 'Fabric Requirement by Project'}</h3>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={aggregated.projectSnapshots}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
                />
                {view === 'financial' ? (
                  <>
                    <Bar dataKey="investment" fill="#fb7185" radius={[4, 4, 0, 0]} name="Investment" />
                    <Bar dataKey="revenue" fill="#34d399" radius={[4, 4, 0, 0]} name="Revenue" />
                  </>
                ) : (
                  <Bar dataKey="fabric" fill="#6366f1" radius={[4, 4, 0, 0]} name="Fabric (Yds)" />
                )}
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Fabric Distribution</h3>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3 mt-4">
            {pieData.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[i % COLORS.length]}} />
                  <span className="text-slate-600">{d.name}</span>
                </div>
                {/* Fix: Explicitly cast value to number to allow use of toFixed method */}
                <span className="font-bold text-slate-900">{(d.value as number).toFixed(1)} Yds</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Conditional Tables based on View */}
      {view === 'fabric' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="p-6 border-b border-slate-50">
              <h3 className="text-lg font-bold text-slate-900">Production Breakdown by Fabric Color</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                    <th className="px-6 py-4">Fabric Color</th>
                    <th className="px-6 py-4">Fabric Code</th>
                    <th className="px-6 py-4 text-indigo-600">Total Yards</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {aggregated.fabricColorMatrix.map((item, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-sm font-medium text-slate-800">
                          <div className="w-2 h-2 rounded-full" style={{backgroundColor: item.color.toLowerCase()}} />
                          {item.color}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">{item.code}</td>
                      <td className="px-6 py-4 text-sm font-bold text-indigo-600">{item.yards.toFixed(2)} Yds</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="p-6 border-b border-slate-50">
              <h3 className="text-lg font-bold text-slate-900">Breakdown by Dress Code</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                    <th className="px-6 py-4">Dress Code</th>
                    <th className="px-6 py-4">Total Pcs</th>
                    <th className="px-6 py-4">Fabric (Yds)</th>
                    <th className="px-6 py-4">Avg Cons</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {aggregated.projectSnapshots.map((p, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-sm font-bold text-slate-800">{p.name}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{p.units} Pcs</td>
                      <td className="px-6 py-4 text-sm font-medium text-slate-900">{p.fabric.toFixed(1)} Yds</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{(p.fabric / (p.units || 1)).toFixed(2)} Yds/Pc</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="p-6 border-b border-slate-50">
            <h3 className="text-lg font-bold text-slate-900">Project Performance Matrix</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                  <th className="px-6 py-4">Dress Code</th>
                  <th className="px-6 py-4">Units</th>
                  <th className="px-6 py-4 text-rose-500">Investment</th>
                  <th className="px-6 py-4 text-emerald-500">Revenue</th>
                  <th className="px-6 py-4 text-indigo-600">Net Profit</th>
                  <th className="px-6 py-4">BEP Units</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {aggregated.projectSnapshots.map((p, i) => (
                  <tr key={i} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-bold text-slate-800">{p.name}</td>
                    <td className="px-6 py-4 text-sm text-slate-600">{p.units} Pcs</td>
                    <td className="px-6 py-4 text-sm font-medium text-slate-600">{formatMMK(p.investment)}</td>
                    <td className="px-6 py-4 text-sm font-medium text-slate-600">{formatMMK(p.revenue)}</td>
                    <td className={`px-6 py-4 text-sm font-bold ${p.profit > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                      {formatMMK(p.profit)}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{Math.ceil(p.bep)} Units</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

const StatCard = ({ title, value, icon, highlight }: { title: string, value: string, icon: React.ReactNode, highlight?: boolean }) => (
  <div className={`bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-2 ${highlight ? 'ring-2 ring-indigo-100 bg-indigo-50/10' : ''}`}>
    <div className="flex items-center justify-between text-slate-400">
      <span className="text-xs font-bold uppercase tracking-widest">{title}</span>
      {icon}
    </div>
    <div className="text-2xl font-extrabold text-slate-900">{value}</div>
  </div>
);

export default Dashboard;
